<?php
defined('_JEXEC') or die('Restricted access');

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

if(!defined('DS'))
{
    define('DS',DIRECTORY_SEPARATOR);
}

class plgSystemSn_joombriInstallerScript
{
    function preflight($type,$parent)
    {
        if(!JFolder::exists(JPATH_ADMINISTRATOR .DS. 'components' .DS. 'com_jblance'))
        {
            Jerror::raiseWarning(null,'لطفا ابتدا افزونه جوم بری را نصب نمایید.');
            return false;
        }
    }

    function postflight($type,$parent)
    {
        /* Enable Plugin */
        $database = JFactory::getDBO();
        $query = "UPDATE `#__extensions` SET `enabled` = 1 WHERE `element` = 'sn_joombri'";
        $database->setQuery($query);
        $database->query();

        /* Move Libraries Files */
        $from = JPATH_ROOT .DS. 'plugins' .DS. 'system' .DS. 'sn_joombri' .DS. 'libraries' .DS;
        $to = JPATH_ROOT .DS. 'libraries' .DS;
        JFolder::copy($from,$to,'',true);
        if(JFolder::exists($from))
        {
            JFolder::delete($from);
        }

        $from = JPATH_ROOT .DS. 'plugins' .DS. 'system' .DS. 'sn_joombri' .DS. 'files' .DS;
        $to = JPATH_ROOT .DS. 'components' .DS. 'com_jblance' .DS. 'gateways' .DS;
        JFolder::copy($from,$to,'',true);
        if(JFolder::exists($from))
        {
            JFolder::delete($from);
        }

        if(strtolower($type) == 'install')
        {
            jimport('sncore.include');
            $name = 'پرداخت آنلاین';
            $query = "INSERT INTO `#__jblance_paymode` (`gateway_name`, `published`, `ordering`, `shortcode`, `gwcode`, `withdrawDesc`, `depositfeeFixed`, `depositfeePerc`, `params`) 
                      VALUES
                      ('".$name."', 1, 6, 'SN', 'snjoombri','Withdraw funds to your sn account.', 0.3, 2.9, '');";

            SNGlobal::insert($query);
        }
    }

    function uninstall($parent)
    {
        $file = JPATH_ROOT .DS. 'components' .DS. 'com_jblance' .DS. 'gateways' .DS. 'class.snjoombri.php';
        if(JFile::exists($file))
        {
            JFile::delete($file);
        }

        $file = JPATH_ROOT .DS. 'components' .DS. 'com_jblance' .DS. 'gateways' .DS. 'images' .DS. 'sn-logo.png';
        if(JFile::exists($file))
        {
            JFile::delete($file);
        }

        jimport('sncore.include');

        $query = "DELETE FROM `#__jblance_paymode` WHERE `gwcode`='snjoombri'";
        SNGlobal::delete($query);
    }
}