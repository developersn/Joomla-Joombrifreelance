<?php
defined('_JEXEC') or die('Restricted access');

jimport('sncore.include');

class snjoombri_class
{
    var $last_error;
    var $ipn_log;
    var $ipn_log_file;
    var $ipn_response;
    var $ipn_data = array();
    var $fields = array();
    var $payconfig = array();
    var $details = array();
    
    function snjoombri_class($payconfig,$details)
    {
        $this->payconfig = $payconfig;
        $this->details = $details;

        SNGlobal::loadLanguage('plg_system_sn_joombri',JPATH_ADMINISTRATOR);
    }
    
    /* Redirect to Bank */
    function snjoombriPayment()
    {
        $payconfig   = $this->payconfig;
    
        $details    = $this->details;
        $amount     = $details['amount'];
        $taxrate    = $details['taxrate'];
        $orderId    = $details['orderid'];
        $itemname   = $details['itemname'];
        $item_num   = $details['item_num'];
        $invoiceNo  = $details['invoiceNo'];

        $amount += $taxrate > 0 ? $taxrate*$amount/100 : 0;

        $backUrl = JRoute::_(JURI::base().'index.php?option=com_jblance&task=membership.returnafterpayment&gateway=snjoombri&invoiceNo='.$invoiceNo.'&orderId='.$orderId);
        $cancelUrl = JRoute::_(JURI::base().'index.php?option=com_jblance&view=membership&layout=thankpayment&type=cancel');

        if($amount > 0)
        {
            $pin = !empty($payconfig->sn_pin) ? $payconfig->sn_pin : '';
            $currency = !empty($payconfig->sn_currency) ? $payconfig->sn_currency : '';
            $sendPayerInfo = !empty($payconfig->sn_send_payer_info) ? $payconfig->sn_send_payer_info : '';

            $amount = SNApi::modifyPrice($amount,$currency);

            $data = array(
                'pin'=> $pin,
                'price'=> $amount,
                'callback'=> $backUrl,
                'order_id'=> $orderId,
                'description'=> '',
                'mobile'=> '',
            );

            list($status,$msg,$resultData) = SNApi::request($data,$sendPayerInfo,'joombri');

            if($status == true)
            {
                $data['bank_callback_details'] = $resultData['bank_callback_details'];
                $data['au'] = $resultData['au'];

                SNApi::clearData();
                SNApi::setData($data);

                $html = '<div class="sn-go-to-bank">'.JText::_('SN_CONNECTING_TO_PORTAL').'</div>';
                $html .= SNGlobal::postData($resultData['form_details']['action'],$resultData['form_details']['fields'],100);
                echo $html;
                return;
            }
        }

        $app = JFactory::getApplication();
        $app->enqueueMessage('<h5>'.$msg.'</h5>','Error');
    }
    
    /* Do Verify */
    function snjoombriReturn($data)
    {
        $orderId = SNGlobal::getVar('order_id','','none','request');
        $au = SNGlobal::getVar('au','','none','request');
        $return = array(
            'success' => false,
        );

        $sessionData = SNApi::getData();
        if(!empty($orderId) && !empty($au) && !empty($sessionData) && $sessionData['order_id'] == $orderId)
        {
            $bankData = array();
            foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
            {
                $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
            }

            $data = array (
                'pin' => $sessionData['pin'],
                'price' => $sessionData['price'],
                'order_id' => $sessionData['order_id'],
                'au' => $au,
                'bank_return' => $bankData,
            );

            list($status,$msg,$resultData) = SNApi::verify($data,'joombri');

            if($status == true)
            {
                $bankAu = !empty($resultData['bank_au']) ? $resultData['bank_au'] : $au;

                $return = array(
                    'success' => true,
                    'invoice_num' => $bankAu,
                );
            }
        }

        return $return;
    }
}

?>